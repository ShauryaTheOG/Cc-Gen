# Fox CC
[-] Black Fox CC Tools 
# Features
> [&] Fast & easy 

> [&] Generate a valid card

> [&] Generate multi valid card

> [&] Credit Card Valid Checker 

> [&] Generate Multi Bin Numbers

> [&] Without limit & Free


# Installation-Linux-Termux

```
apt-get update && apt-get upgrade && apt-get install git python3 nodejs
```
```
git clone https://github.com/BlackFoxTM/Fox-CC
```
```
cd Fox-CC
```
```
pip3 install -r requirements.txt
```
```
python3 cc.py
```

# Installation-Windows
### Download NodeJs Installer from [This Link](https://nodejs.org/en/)

### Then Download This project as zip 

### After That Open Cmd and go the Directory that you downloaded 

## run `python cc.py`
